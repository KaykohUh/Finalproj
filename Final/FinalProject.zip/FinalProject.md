```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
```


```python
goog_stock = pd.read_csv(r'C:\Users\asmjehdfg\Desktop\DataSets\GOOG.csv')
```


```python
goog_stock.head
```




    <bound method NDFrame.head of             Date        Open        High         Low       Close   Adj Close  \
    0     2015-01-02   26.378078   26.490770   26.133251   26.168653   26.168653   
    1     2015-01-05   26.091366   26.144720   25.582764   25.623152   25.623152   
    2     2015-01-06   25.679497   25.738087   24.983908   25.029282   25.029282   
    3     2015-01-07   25.280592   25.292759   24.914099   24.986401   24.986401   
    4     2015-01-08   24.831326   25.105074   24.482782   25.065184   25.065184   
    ...          ...         ...         ...         ...         ...         ...   
    2342  2024-04-24  159.089996  161.389999  158.820007  161.100006  161.100006   
    2343  2024-04-25  153.360001  158.279999  152.768005  157.949997  157.949997   
    2344  2024-04-26  175.990005  176.419998  171.399994  173.690002  173.690002   
    2345  2024-04-29  170.770004  171.380005  167.059998  167.899994  167.899994   
    2346  2024-04-30  167.380005  169.869995  164.500000  164.639999  164.639999   
    
            Volume  
    0     28951268  
    1     41196796  
    2     57998800  
    3     41301082  
    4     67071641  
    ...        ...  
    2342  19485700  
    2343  36197800  
    2344  56500800  
    2345  35914600  
    2346  29420800  
    
    [2347 rows x 7 columns]>




```python
goog_stock['50 Day MA'] = goog_stock['Close'].rolling(window=50).mean()
goog_stock['200 Day MA'] = goog_stock['Close'].rolling(window=200).mean()
goog_stock['52 Week High'] = goog_stock['Close'].rolling(window=52*5, min_periods=1).max()

```


```python
plt.figure(figsize=(10, 6))
plt.plot(goog_stock['Date'], goog_stock['Close'], label='Original Data')
plt.plot(goog_stock['Date'], goog_stock['50 Day MA'], label='50-Day Moving Average')
plt.plot(goog_stock['Date'], goog_stock['200 Day MA'], label='200-Day Moving Average')
plt.plot(goog_stock['Date'], goog_stock['52 Week High'], label='52-Week High')
plt.xlabel('Date')
plt.ylabel('Value')
plt.title('50-Day Moving Average')
plt.legend()


plt.show()
```


    
![png](output_4_0.png)
    



```python
goog_stock['Date'] = pd.to_datetime(goog_stock['Date'])
monthly_data = goog_stock.groupby(pd.Grouper(key='Date', freq='M')).mean()
plt.figure(figsize=(10, 6))
plt.plot(monthly_data.index, monthly_data['Close'], marker='o')
plt.xlabel('Date')
plt.ylabel('Mean Value')
plt.title('Google Average Stock (Monthly Close)')
plt.xticks(rotation=45)
plt.grid(True)
plt.show()
```


    
![png](output_5_0.png)
    



```python
sns.set(style="darkgrid")
plt.figure(figsize=(12, 6))
sns.lineplot(x="Date", y="Close", data=goog_stock)
plt.title('Google Stock Price (Close) Over Time')
plt.xlabel('Date')
plt.ylabel('Close Price (USD)')
plt.xticks(rotation=45)
plt.grid(True)
plt.show()
```

    C:\Users\asmjehdfg\anaconda3\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    C:\Users\asmjehdfg\anaconda3\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_6_1.png)
    



```python

```
